# Los Angeles County Metropolitan Transportation Authority's GTFS for Rail.
## updated 2023-11-04 01:30:08 PDT America/Los_Angeles

As of May 6th, 2016 The LACMTA is now publishing our Bus and Rail Services in separate Google Transit Exports ONLY. As a customer service, and to allow us to update these files more frequently, we have split these files up. The new rail-only export will be updated Daily (generally Tuesday-Saturday mornings), to allow us to send out more timely information and to allow our users to capture all temporary rail service changes that may occur on a daily basis. The bus-only exports will continue to be provided as large-scale changes to the system occur -- generally once every one or two months. We will NOT continue to maintain the combined service feeds.

### Join our developer community at [http://developer.metro.net](http://developer.metro.net) to learn more about using this data.

### Link to LACMTA's Bus Data repository: [https://gitlab.com/LACMTA/gtfs_bus/](https://gitlab.com/LACMTA/gtfs_bus/)

---

### Evergreen link to the gtfs_rail.zip archive: [https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip](https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1699086608.9770088)

### Today's link to the gtfs_rail.zip archive: [https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1699086608.9770088](https://gitlab.com/LACMTA/gtfs_rail/raw/master/gtfs_rail.zip?1699086608.9770088)


### zip archive contents
```
 Length   Creation datetime         Name        
-----------------------------------------------
     174  2023-11-04 00:15   agency.txt         
    1974  2023-11-04 00:15   calendar.txt       
     140  2023-11-04 00:15   calendar_dates.txt 
     578  2023-11-04 00:15   routes.txt         
  372648  2023-05-24 12:13   shapes.txt         
   35643  2023-06-20 08:11   stops.txt          
20540300  2023-11-04 00:17   stop_times.txt     
  415621  2023-11-04 00:15   trips.txt          
     285  2023-11-04 00:33   feed_info.txt      
```

## Summary of changes
```
commit 5ec788aac52b8d8e1e89f13da166388e83db6b4f
Author: activebatch <activebatch@MTAABEXEC01>
Date:   Fri Nov 3 01:30:18 2023 -0700

    2023-11-03 01:30:12 PDT America/Los_Angeles

 README.md          |    36 +-
 calendar.txt       |    19 +-
 calendar_dates.txt |     3 +
 gtfs_rail.zip      |   Bin 1137212 -> 1127448 bytes
 stop_times.txt     | 11675 +++++++++++++++++++++++----------------------------
 trips.txt          |  1287 +++---
 6 files changed, 5751 insertions(+), 7269 deletions(-)
```

## Subscribing to changes

### Get the latest commit ID with Curl

```
#!/bin/sh

url="https://gitlab.com/LACMTA/gtfs_rail/commits/master.atom"

curl --silent "$url" | grep -E '(title>|updated>)' | \
  sed -n '4,$p' | \
  sed -e 's/<title>//' -e 's/<\/title>//' -e 's/<updated>/   /' \
      -e 's/<\/updated>//' | \
  head -2 | fmt

# returns:
# 2015-12-31T13:09:36Z
#    new info from SPA and instructions on preparing the archive
```

### Get the latest commit ID with Python

```
#!/bin/env python

import feedparser

url = 'https://gitlab.com/LACMTA/gtfs_rail/commits/master.atom'
d = feedparser.parse(url)
lastupdate = d['feed']['updated']

print(lastupdate)

```

See the [http://developer.metro.net/the-basics/policies/terms-and-conditions/](http://developer.metro.net/the-basics/policies/terms-and-conditions/) page for terms and conditions.
